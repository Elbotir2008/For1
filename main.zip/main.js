// for lesson

// let k = 13;
// let n = 2;
// for (; n <= k; n++) {
//   console.log(k);
// }

// for 1
// let a = 10;
// let b = 20;
// let S;
// for (; a <= b; a++) {
//   console.log(a);
// }

// for 2
// let a = 10;
// let b = 20;
// let S = 1;
// for (; a < b; a++) {
//   console.log(a);
// }
// !qilaolmadim

// for 3
// let sum = 10000;
// let a = 10;
// let b = 1;
// for (; b <= a; b++) {
//   console.log(b * sum);
// }

// for 4
// let sum = 10000;
// let a = 2;
// let b = 0.1;
// for (; b <= a; b++) {
//   console.log(b);
// }
// !qilaolmadim

// for 5
// let a = 10;
// let b = 20;
// for (; a <= b; a++) {
//  console.log(a + a)
// }

// for 6
// let a = 10;
// let b = 20;
// let S;
// for (; a <= b; a++) {
//   console.log(a * a);
// }

// for 7
// let a = 10;
// let b = 20;
// let S;
// for (; a <= b; a++) {
//   console.log(a * a);
// }
// !ishlanmagan

// for 8
// let S = 1;
// let a = 10;
// for (i = 1; i <= 10; i++) {
//   console.log(i / S);
// }

// for 9
let S = 1.1;
let a = 2;
for (i = 1; i <= 2; i++) {
  console.log(i);
}
